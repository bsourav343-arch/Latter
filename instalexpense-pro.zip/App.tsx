
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Wallet, 
  Settings as SettingsIcon, 
  TrendingUp
} from 'lucide-react';
import { dbService } from './db';
import { Customer, Installment, Expense, Settings, Screen } from './types';
import Dashboard from './components/Dashboard';
import CustomerList from './components/CustomerList';
import ExpenseLedger from './components/ExpenseLedger';
import SettingsView from './components/SettingsView';
import CustomerDetail from './components/CustomerDetail';
import CustomerForm from './components/CustomerForm';
import RevenueView from './components/RevenueView';

const App: React.FC = () => {
  const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [installments, setInstallments] = useState<Installment[]>([]);
  const [settings, setSettings] = useState<Settings>({ adminName: 'Manager' });
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [isAddingCustomer, setIsAddingCustomer] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | undefined>(undefined);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [c, e, i, s] = await Promise.all([
      dbService.getCustomers(),
      dbService.getExpenses(),
      dbService.getInstallments(),
      dbService.getSettings()
    ]);
    setCustomers(c);
    setExpenses(e);
    setInstallments(i);
    setSettings(s);
  };

  const handleSelectCustomer = (id: string) => {
    setSelectedCustomerId(id);
    setActiveScreen('customerDetail');
  };

  const handleEditCustomer = (customer: Customer) => {
    setCustomerToEdit(customer);
    setIsAddingCustomer(true);
  };

  const navigateTo = (screen: Screen) => {
    setActiveScreen(screen);
    setIsAddingCustomer(false);
    setCustomerToEdit(undefined);
  };

  const renderContent = () => {
    if (isAddingCustomer) {
      return (
        <CustomerForm 
          initialData={customerToEdit}
          onClose={() => {
            setIsAddingCustomer(false);
            setCustomerToEdit(undefined);
          }} 
          onSave={async (c) => {
            await dbService.saveCustomer(c);
            loadData();
            setIsAddingCustomer(false);
            setCustomerToEdit(undefined);
          }}
        />
      );
    }

    switch (activeScreen) {
      case 'dashboard':
        return <Dashboard 
          customers={customers} 
          expenses={expenses} 
          installments={installments} 
          onNavigateToCustomers={() => setActiveScreen('customers')}
        />;
      case 'customers':
        return <CustomerList 
          customers={customers} 
          onAdd={() => {
            setCustomerToEdit(undefined);
            setIsAddingCustomer(true);
          }}
          onSelect={handleSelectCustomer}
          installments={installments}
        />;
      case 'expenses':
        return <ExpenseLedger 
          expenses={expenses} 
          onSave={async (e) => {
            await dbService.saveExpense(e);
            loadData();
          }}
        />;
      case 'revenue':
        return <RevenueView 
          customers={customers}
          installments={installments}
          expenses={expenses}
        />;
      case 'settings':
        return <SettingsView 
          settings={settings} 
          onSave={async (s) => {
            await dbService.saveSettings(s);
            setSettings(s);
          }}
        />;
      case 'customerDetail':
        const cust = customers.find(c => c.id === selectedCustomerId);
        return cust ? (
          <CustomerDetail 
            customer={cust} 
            installments={installments.filter(i => i.customerId === cust.id)}
            onBack={() => setActiveScreen('customers')}
            onUpdate={async (updated) => {
              await dbService.saveCustomer(updated);
              loadData();
            }}
            onEdit={handleEditCustomer}
            onAddInstallment={async (inst) => {
              await dbService.saveInstallment(inst);
              loadData();
            }}
            onDelete={async (id) => {
              if(confirm('Are you sure you want to delete this customer?')) {
                await dbService.deleteCustomer(id);
                loadData();
                setActiveScreen('customers');
              }
            }}
          />
        ) : null;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#050a18] text-slate-200">
      {/* Header */}
      <header className="no-print p-6 flex justify-between items-center bg-[#050a18] sticky top-0 z-50 border-b border-white/10 backdrop-blur-xl">
        <div className="flex items-center space-x-4">
          <div 
            onClick={() => setActiveScreen('settings')}
            className="w-12 h-12 rounded-2xl overflow-hidden bg-blue-600 flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition-all border border-white/10 shadow-lg shadow-blue-500/20"
          >
            {settings.adminPhoto ? (
              <img src={settings.adminPhoto} alt="Admin" className="w-full h-full object-cover" />
            ) : (
              <span className="text-xl uppercase">{settings.adminName ? settings.adminName[0] : 'A'}</span>
            )}
          </div>
          <div>
            <h1 className="text-xs font-medium text-blue-400 uppercase tracking-widest">
              Welcome back,
            </h1>
            <p className="text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              {settings.adminName}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => setActiveScreen('settings')}
            className="p-2 glass rounded-full hover:bg-white/10 transition-colors"
          >
            <SettingsIcon size={20} />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24 max-w-6xl mx-auto w-full px-4 pt-6">
        {renderContent()}
      </main>

      {/* Navigation Bar - Reordered to Dashboard -> Users -> Ledger -> Revenue -> Sets */}
      <nav className="no-print fixed bottom-6 left-1/2 -translate-x-1/2 w-[95%] max-w-lg glass rounded-3xl p-3 flex justify-around items-center electric-blue-glow z-50">
        <NavButton 
          active={activeScreen === 'dashboard'} 
          onClick={() => navigateTo('dashboard')} 
          icon={<LayoutDashboard size={24} />} 
          label="Dash"
        />
        <NavButton 
          active={activeScreen === 'customers' || activeScreen === 'customerDetail'} 
          onClick={() => navigateTo('customers')} 
          icon={<Users size={24} />} 
          label="Users"
        />
        <NavButton 
          active={activeScreen === 'expenses'} 
          onClick={() => navigateTo('expenses')} 
          icon={<Wallet size={24} />} 
          label="Ledger"
        />
        <NavButton 
          active={activeScreen === 'revenue'} 
          onClick={() => navigateTo('revenue')} 
          icon={<TrendingUp size={24} />} 
          label="Revenue"
        />
        <NavButton 
          active={activeScreen === 'settings'} 
          onClick={() => navigateTo('settings')} 
          icon={<SettingsIcon size={24} />} 
          label="Sets"
        />
      </nav>
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center p-2 rounded-2xl transition-all duration-300 ${active ? 'text-blue-400 bg-blue-400/10' : 'text-slate-400 hover:text-slate-200'}`}
  >
    {icon}
    <span className="text-[10px] mt-1 font-semibold">{label}</span>
  </button>
);

export default App;
