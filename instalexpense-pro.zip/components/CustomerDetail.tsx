
import React, { useState, useMemo } from 'react';
import { 
  ArrowLeft, Edit, Trash2, Printer, 
  Plus, History, CreditCard, Clock, 
  AlertCircle, Download, CheckCircle2, TrendingDown, Layers, MapPin, Shield
} from 'lucide-react';
import { 
  ComposedChart, 
  Line, 
  Area, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import * as XLSX from 'xlsx';
import { Customer, Installment } from '../types';

interface CustomerDetailProps {
  customer: Customer;
  installments: Installment[];
  onBack: () => void;
  onUpdate: (c: Customer) => void;
  onEdit: (c: Customer) => void;
  onAddInstallment: (i: Installment) => void;
  onDelete: (id: string) => void;
}

const CustomerDetail: React.FC<CustomerDetailProps> = ({ 
  customer, installments, onBack, onUpdate, onEdit, onAddInstallment, onDelete 
}) => {
  const [showInstallmentModal, setShowInstallmentModal] = useState(false);
  const [instAmount, setInstAmount] = useState('');
  const [instType, setInstType] = useState<'regular' | 'advance'>('regular');

  const stats = useMemo(() => {
    const totalToReceive = customer.principal * (1 + customer.interestRate / 100);
    const paid = installments.reduce((sum, curr) => sum + curr.amount, 0);
    const balance = totalToReceive - paid;
    const weeklyInstallment = totalToReceive / customer.totalWeeks;
    
    // Calculation for missed weeks
    const startDate = new Date(customer.startDate);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - startDate.getTime());
    const weeksPassed = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7));
    
    const expectedPayments = Math.min(weeksPassed, customer.totalWeeks);
    const completedInstallments = installments.length;
    const missedWeeks = Math.max(0, expectedPayments - completedInstallments);
    const dueAmount = (missedWeeks * weeklyInstallment) + customer.fineAmount;

    return {
      totalToReceive,
      paid,
      balance,
      weeklyInstallment,
      completedInstallments,
      remainingInstallments: Math.max(0, customer.totalWeeks - completedInstallments),
      missedWeeks,
      dueAmount
    };
  }, [customer, installments]);

  const chartData = useMemo(() => {
    const sorted = [...installments].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    let runningBalance = stats.totalToReceive;
    
    const data = sorted.map(inst => {
      runningBalance -= inst.amount;
      return {
        date: new Date(inst.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        amount: inst.amount,
        balance: Math.max(0, runningBalance),
        type: inst.type
      };
    });

    // Add initial state
    return [{ date: 'Start', amount: 0, balance: stats.totalToReceive, type: 'init' }, ...data];
  }, [installments, stats.totalToReceive]);

  const handlePay = () => {
    if (!instAmount) return;
    const newInst: Installment = {
      id: crypto.randomUUID(),
      customerId: customer.id,
      amount: parseFloat(instAmount),
      date: new Date().toISOString(),
      type: instType
    };
    onAddInstallment(newInst);
    setShowInstallmentModal(false);
    setInstAmount('');
  };

  const handleExportExcel = () => {
    const data = installments.map(i => ({
      Date: new Date(i.date).toLocaleDateString(),
      Amount: i.amount,
      Type: i.type,
      Balance: stats.totalToReceive - installments.filter(inst => inst.date <= i.date).reduce((s, c) => s + c.amount, 0)
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "History");
    XLSX.writeFile(wb, `${customer.name}_Statement.xlsx`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Controls */}
      <div className="no-print flex items-center justify-between">
        <button onClick={onBack} className="p-2 glass rounded-2xl hover:bg-white/10">
          <ArrowLeft size={20} />
        </button>
        <div className="flex space-x-2">
          <button onClick={() => onEdit(customer)} className="p-2 glass rounded-2xl hover:bg-blue-500/20 text-blue-400" title="Edit Profile">
            <Edit size={20} />
          </button>
          <button onClick={handlePrint} className="p-2 glass rounded-2xl hover:bg-blue-500/20 text-blue-400">
            <Printer size={20} />
          </button>
          <button onClick={handleExportExcel} className="p-2 glass rounded-2xl hover:bg-emerald-500/20 text-emerald-400">
            <Download size={20} />
          </button>
          <button onClick={() => onDelete(customer.id)} className="p-2 glass rounded-2xl hover:bg-rose-500/20 text-rose-400">
            <Trash2 size={20} />
          </button>
        </div>
      </div>

      {/* Main Profile Card */}
      <div className="glass p-8 rounded-3xl relative overflow-hidden">
        <div className="hidden print-only mb-8 text-black border-b pb-4">
          <h1 className="text-3xl font-bold text-center">LOAN STATEMENT</h1>
          <p className="text-gray-600 text-center">Generated on {new Date().toLocaleDateString()}</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 relative z-10">
          <div className="w-32 h-32 rounded-3xl bg-blue-500/20 border border-blue-500/30 overflow-hidden flex-shrink-0 mx-auto md:mx-0">
            {customer.photo ? (
              <img src={customer.photo} alt={customer.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Clock className="text-blue-400" size={40} />
              </div>
            )}
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center justify-center md:justify-start space-x-2 mb-1">
                  <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 text-[10px] font-bold uppercase rounded-md flex items-center">
                    <Layers size={10} className="mr-1" />
                    {customer.groupName || 'Unassigned Group'}
                  </span>
                </div>
                <h2 className="text-3xl font-bold text-white mb-1">{customer.name}</h2>
                <div className="space-y-1">
                  <p className="text-slate-400 text-sm">Guardian: {customer.guardianName} • ID: {customer.uniqueId}</p>
                  {customer.idCardNumber && (
                    <p className="text-slate-400 text-sm font-medium">Aadhaar/Voter: <span className="text-blue-400">{customer.idCardNumber}</span></p>
                  )}
                  {/* Address Display */}
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-4 gap-y-1 mt-2 text-xs text-slate-500 italic">
                    <div className="flex items-center"><MapPin size={12} className="mr-1" /> {customer.village || 'N/A'}, {customer.district || 'N/A'}</div>
                    <div className="flex items-center"><Shield size={12} className="mr-1" /> PS: {customer.policeStation || 'N/A'}</div>
                    <div className="flex items-center">Pin: {customer.pinCode || 'N/A'}</div>
                  </div>
                </div>
              </div>
              <div className="no-print flex flex-col gap-2">
                <button 
                  onClick={() => setShowInstallmentModal(true)}
                  className="px-6 py-3 bg-blue-600 rounded-2xl font-bold flex items-center justify-center space-x-2 electric-blue-glow hover:bg-blue-500 transition-colors w-full"
                >
                  <Plus size={18} />
                  <span>Collect Payment</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Total Loan</p>
                <p className="text-xl font-bold">₹{stats.totalToReceive.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Amount Paid</p>
                <p className="text-xl font-bold text-emerald-400">₹{stats.paid.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Remaining</p>
                <p className="text-xl font-bold text-blue-400">₹{stats.balance.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Weekly Installment</p>
                <p className="text-xl font-bold text-purple-400">₹{stats.weeklyInstallment.toFixed(2)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment History Chart */}
      <div className="glass p-6 rounded-[32px] overflow-hidden no-print">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold flex items-center text-lg">
            <TrendingDown className="mr-2 text-blue-400" size={22} />
            Repayment Trajectory
          </h3>
          <div className="flex space-x-4 text-[10px] uppercase font-bold tracking-widest">
            <div className="flex items-center"><div className="w-2 h-2 rounded-full bg-blue-500 mr-2" /> Regular</div>
            <div className="flex items-center"><div className="w-2 h-2 rounded-full bg-purple-500 mr-2" /> Advance</div>
            <div className="flex items-center"><div className="w-2 h-2 rounded-full bg-blue-500/20 border border-blue-500/40 mr-2" /> Balance</div>
          </div>
        </div>
        <div className="h-[280px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
              <XAxis 
                dataKey="date" 
                stroke="#475569" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
                dy={10}
              />
              <YAxis 
                yAxisId="left"
                stroke="#475569" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
                tickFormatter={(val) => `₹${val}`}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#475569" 
                fontSize={10} 
                tickLine={false} 
                axisLine={false} 
                tickFormatter={(val) => `₹${val}`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                  border: '1px solid rgba(255, 255, 255, 0.1)', 
                  borderRadius: '16px',
                  backdropFilter: 'blur(8px)',
                  boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)'
                }}
                itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontSize: '10px' }}
                formatter={(value) => [`₹${value.toLocaleString()}`]}
              />
              <Area 
                yAxisId="right"
                type="monotone" 
                dataKey="balance" 
                stroke="#3b82f6" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#balanceGradient)" 
                name="Remaining Balance"
              />
              <Bar 
                yAxisId="left" 
                dataKey="amount" 
                barSize={24} 
                radius={[6, 6, 0, 0]}
                name="Payment Amount"
              >
                {chartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.type === 'advance' ? '#a855f7' : '#3b82f6'} 
                  />
                ))}
              </Bar>
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Health & Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass p-6 rounded-3xl flex flex-col justify-between">
          <h3 className="font-bold mb-4 flex items-center text-lg">
            <Clock className="mr-2 text-blue-400" size={20} />
            Payment Status
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 rounded-2xl bg-white/5">
              <span className="text-slate-400">Installments Completed</span>
              <span className="font-bold">{stats.completedInstallments} / {customer.totalWeeks}</span>
            </div>
            <div className={`flex justify-between items-center p-4 rounded-2xl ${stats.missedWeeks > 0 ? 'bg-rose-500/10' : 'bg-emerald-500/10'}`}>
              <div className="flex items-center">
                {stats.missedWeeks > 0 ? <AlertCircle className="mr-2 text-rose-400" size={18} /> : <CheckCircle2 className="mr-2 text-emerald-400" size={18} />}
                <span className={stats.missedWeeks > 0 ? 'text-rose-400' : 'text-emerald-400'}>Missed Weeks</span>
              </div>
              <span className={`font-bold ${stats.missedWeeks > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>{stats.missedWeeks}</span>
            </div>
            <div className="flex justify-between items-center p-4 rounded-2xl bg-white/5">
              <span className="text-slate-400">Total Due + Fine</span>
              <div className="text-right">
                <span className="font-bold block text-white">₹{stats.dueAmount.toLocaleString()}</span>
                {customer.fineAmount > 0 && <span className="text-[10px] text-rose-400">Includes ₹{customer.fineAmount} fine</span>}
              </div>
            </div>
          </div>
        </div>

        <div className="glass p-6 rounded-3xl max-h-80 overflow-y-auto custom-scrollbar">
          <h3 className="font-bold mb-4 flex items-center sticky top-0 bg-[#0c1424] backdrop-blur-sm pb-2 z-10 text-lg">
            <History className="mr-2 text-purple-400" size={20} />
            Recent Transactions
          </h3>
          <div className="space-y-3">
            {installments.length > 0 ? installments.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(inst => (
              <div key={inst.id} className="flex justify-between items-center p-3 rounded-xl border border-white/5 hover:bg-white/5">
                <div>
                  <p className="text-sm font-bold">{new Date(inst.date).toLocaleDateString()}</p>
                  <p className="text-[10px] text-slate-500 uppercase tracking-widest">{inst.type}</p>
                </div>
                <p className="font-bold text-emerald-400">+₹{inst.amount}</p>
              </div>
            )) : (
              <div className="py-10 text-center text-slate-500 italic text-sm">No transactions yet</div>
            )}
          </div>
        </div>
      </div>

      {/* Installment Modal */}
      {showInstallmentModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm no-print">
          <div className="glass p-8 rounded-[40px] w-full max-w-sm border border-white/10 electric-blue-glow">
            <h3 className="text-2xl font-bold mb-6">Payment Entry</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-400 uppercase font-bold mb-2 block">Amount (₹)</label>
                <input 
                  type="number" 
                  value={instAmount}
                  onChange={(e) => setInstAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 focus:ring-2 focus:ring-blue-500 focus:outline-none text-white text-xl font-bold"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 uppercase font-bold mb-2 block">Payment Type</label>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setInstType('regular')}
                    className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all ${instType === 'regular' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-white/5 text-slate-400'}`}
                  >
                    Regular
                  </button>
                  <button 
                    onClick={() => setInstType('advance')}
                    className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all ${instType === 'advance' ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20' : 'bg-white/5 text-slate-400'}`}
                  >
                    Advance
                  </button>
                </div>
              </div>

              <div className="flex gap-2 mt-8">
                <button 
                  onClick={() => setShowInstallmentModal(false)}
                  className="flex-1 py-4 bg-white/5 rounded-2xl font-bold hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handlePay}
                  className="flex-1 py-4 bg-blue-600 rounded-2xl font-bold electric-blue-glow hover:bg-blue-500 transition-colors"
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDetail;
