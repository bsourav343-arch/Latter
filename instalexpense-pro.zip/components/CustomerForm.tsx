import React, { useState, useEffect } from 'react';
import { 
  Camera, Save, X, Phone, User, Hash, 
  Percent, Calendar, Layers, Contact, 
  MapPin, Building, Navigation, Shield, 
  Loader2 
} from 'lucide-react';
import { Customer } from '../types';

interface CustomerFormProps {
  onClose: () => void;
  onSave: (c: Customer) => void;
  initialData?: Customer;
}

const CustomerForm: React.FC<CustomerFormProps> = ({ onClose, onSave, initialData }) => {
  const [isFetching, setIsFetching] = useState(false);
  const [formData, setFormData] = useState<Partial<Customer>>(initialData || {
    name: '',
    groupName: '',
    uniqueId: '',
    idCardNumber: '',
    guardianName: '',
    phoneNumber: '',
    principal: 0,
    interestRate: 0,
    totalWeeks: 12,
    startDate: new Date().toISOString().split('T')[0],
    fineAmount: 0,
    pinCode: '',
    village: '',
    state: '',
    district: '',
    policeStation: ''
  });

  useEffect(() => {
    const fetchAddress = async (pin: string) => {
      if (pin.length !== 6) return;
      
      setIsFetching(true);
      try {
        const response = await fetch(`https://api.postalpincode.in/pincode/${pin}`);
        const data = await response.json();
        
        if (data && data[0] && data[0].Status === "Success") {
          const postOffice = data[0].PostOffice[0];
          setFormData(prev => ({
            ...prev,
            village: postOffice.Name,
            district: postOffice.District,
            state: postOffice.State,
            policeStation: postOffice.Block !== 'NA' ? postOffice.Block : (prev.policeStation || '')
          }));
        }
      } catch (error) {
        console.error("PIN Code fetch error:", error);
      } finally {
        setIsFetching(false);
      }
    };

    if (formData.pinCode && formData.pinCode.length === 6) {
      fetchAddress(formData.pinCode);
    }
  }, [formData.pinCode]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: keyof Customer) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, [field]: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData as Customer,
      id: initialData?.id || crypto.randomUUID()
    });
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold">{initialData ? `Edit Profile: ${initialData.name}` : 'New Loan Registry'}</h2>
        <button onClick={onClose} className="p-2 glass rounded-full hover:bg-white/10">
          <X size={20} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DocUpload label="Customer Photo" value={formData.photo} onChange={(e) => handleFileChange(e, 'photo')} />
          <DocUpload label="Aadhaar Card Image" value={formData.aadhaarCard} onChange={(e) => handleFileChange(e, 'aadhaarCard')} />
          <DocUpload label="Voter ID Card Image" value={formData.voterId} onChange={(e) => handleFileChange(e, 'voterId')} />
        </div>

        <div className="glass p-6 rounded-[32px] space-y-4">
          <h3 className="text-sm font-bold text-blue-400 uppercase tracking-widest mb-4 flex items-center">
            <User className="mr-2" size={16} />
            Personal Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormInput label="Group Name" name="groupName" value={formData.groupName} onChange={handleChange} icon={<Layers size={18} />} />
            <FormInput label="Full Name" name="name" value={formData.name} onChange={handleChange} icon={<User size={18} />} />
            <FormInput label="Unique ID / Account #" name="uniqueId" value={formData.uniqueId} onChange={handleChange} icon={<Hash size={18} />} />
            <FormInput label="Aadhaar / Voter ID Number" name="idCardNumber" value={formData.idCardNumber} onChange={handleChange} icon={<Contact size={18} />} />
            <FormInput label="Guardian's Name" name="guardianName" value={formData.guardianName} onChange={handleChange} icon={<User size={18} />} />
            <FormInput label="Phone Number" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} icon={<Phone size={18} />} />
          </div>
        </div>

        <div className="glass p-6 rounded-[32px] space-y-4 relative">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold text-orange-400 uppercase tracking-widest flex items-center">
              <MapPin className="mr-2" size={16} />
              Address Information
            </h3>
            {isFetching && (
              <div className="flex items-center text-xs text-blue-400 animate-pulse">
                <Loader2 size={12} className="animate-spin mr-1" />
                Auto-filling...
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormInput 
              label="Pin Code (6-digit)" 
              name="pinCode" 
              value={formData.pinCode} 
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                if (e.target.value.length <= 6) handleChange(e);
              }} 
              icon={<Hash size={18} />} 
              placeholder="700001"
            />
            <FormInput 
              label="Village / Area" 
              name="village" 
              value={formData.village} 
              onChange={handleChange} 
              icon={<Building size={18} />} 
              className={isFetching ? "animate-pulse" : ""}
            />
            <FormInput 
              label="Police Station" 
              name="policeStation" 
              value={formData.policeStation} 
              onChange={handleChange} 
              icon={<Shield size={18} />} 
            />
            <FormInput 
              label="District" 
              name="district" 
              value={formData.district} 
              onChange={handleChange} 
              icon={<MapPin size={18} />} 
              className={isFetching ? "animate-pulse" : ""}
            />
            <FormInput 
              label="State" 
              name="state" 
              value={formData.state} 
              onChange={handleChange} 
              icon={<Navigation size={18} />} 
              className={isFetching ? "animate-pulse" : ""}
            />
          </div>
        </div>

        <div className="glass p-6 rounded-[32px] space-y-4">
          <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-widest mb-4">Financial Terms</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FormInput label="Principal Amount (₹)" name="principal" type="number" value={formData.principal} onChange={handleChange} icon={<span className="text-sm font-bold">₹</span>} />
            <FormInput label="Flat Interest (%)" name="interestRate" type="number" value={formData.interestRate} onChange={handleChange} icon={<span className="text-xs">%</span>} />
            <FormInput label="Total Weeks" name="totalWeeks" type="number" value={formData.totalWeeks} onChange={handleChange} icon={<Calendar size={18} />} />
            <FormInput label="Start Date" name="startDate" type="date" value={formData.startDate} onChange={handleChange} />
            <FormInput label="Initial Fine (Optional ₹)" name="fineAmount" type="number" value={formData.fineAmount} onChange={handleChange} />
          </div>
        </div>

        <button 
          type="submit"
          className="w-full py-5 bg-blue-600 rounded-[32px] font-bold text-lg flex items-center justify-center space-x-2 electric-blue-glow hover:bg-blue-500 transition-all transform active:scale-[0.98]"
        >
          <Save size={20} />
          <span>{initialData ? 'Update Profile' : 'Authorize & Create Loan'}</span>
        </button>
      </form>
    </div>
  );
};

const FormInput: React.FC<{ 
  label: string; 
  name: string; 
  value: any; 
  onChange: any; 
  icon?: React.ReactNode; 
  type?: string; 
  placeholder?: string;
  className?: string;
}> = ({ label, name, value, onChange, icon, type = 'text', placeholder, className }) => (
  <div className={className || ''}>
    <label className="text-xs text-slate-500 font-bold mb-2 block">{label}</label>
    <div className="relative">
      {icon && <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 flex items-center justify-center w-5 h-5">{icon}</div>}
      <input 
        type={type} 
        name={name}
        value={value || ''}
        onChange={onChange}
        placeholder={placeholder}
        className={`w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-4 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all text-white ${icon ? 'pl-12' : ''}`}
      />
    </div>
  </div>
);

const DocUpload: React.FC<{ label: string; value?: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ label, value, onChange }) => (
  <div className="glass p-4 rounded-3xl text-center flex flex-col items-center">
    <label className="text-xs text-slate-400 font-bold mb-3">{label}</label>
    <div className="relative w-full aspect-video md:aspect-square bg-white/5 rounded-2xl border-2 border-dashed border-white/10 flex items-center justify-center overflow-hidden group">
      {value ? (
        <img src={value} alt={label} className="w-full h-full object-cover" />
      ) : (
        <Camera className="text-white/20 group-hover:text-blue-500 transition-colors" size={32} />
      )}
      <input 
        type="file" 
        accept="image/*" 
        onChange={onChange}
        className="absolute inset-0 opacity-0 cursor-pointer"
      />
    </div>
    <p className="text-[10px] text-slate-500 mt-2">Click to capture/upload</p>
  </div>
);

export default CustomerForm;