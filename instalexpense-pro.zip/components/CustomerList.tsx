
import React, { useState, useMemo } from 'react';
import { Search, Plus, Filter, User, Phone, DollarSign, Calendar, Layers, ChevronDown, ChevronRight } from 'lucide-react';
import { Customer, Installment } from '../types';

interface CustomerListProps {
  customers: Customer[];
  installments: Installment[];
  onAdd: () => void;
  onSelect: (id: string) => void;
}

const CustomerList: React.FC<CustomerListProps> = ({ customers, installments, onAdd, onSelect }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.uniqueId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.groupName && c.groupName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const groupedCustomers = useMemo(() => {
    const groups: Record<string, Customer[]> = {};
    filteredCustomers.forEach(c => {
      const gName = c.groupName?.trim() || 'General Group';
      if (!groups[gName]) groups[gName] = [];
      groups[gName].push(c);
    });
    // Sort keys alphabetically
    const sortedKeys = Object.keys(groups).sort((a, b) => a.localeCompare(b));
    const sortedGroups: Record<string, Customer[]> = {};
    sortedKeys.forEach(key => {
      sortedGroups[key] = groups[key];
    });
    return sortedGroups;
  }, [filteredCustomers]);

  const toggleGroup = (groupName: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupName]: !prev[groupName]
    }));
  };

  const getCustomerProgress = (customerId: string, principal: number, rate: number) => {
    const totalToPay = principal * (1 + rate / 100);
    const paid = installments
      .filter(i => i.customerId === customerId)
      .reduce((sum, curr) => sum + curr.amount, 0);
    return {
      percentage: Math.min(Math.round((paid / totalToPay) * 100), 100),
      remaining: totalToPay - paid
    };
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Customer Portfolio</h2>
        <div className="flex gap-2">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
              type="text" 
              placeholder="Search ID, Name or Group..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-2xl glass border-none focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-slate-500 text-white"
            />
          </div>
          <button 
            onClick={onAdd}
            className="p-3 bg-blue-600 rounded-2xl hover:bg-blue-500 transition-colors electric-blue-glow"
          >
            <Plus size={20} />
          </button>
        </div>
      </div>

      <div className="space-y-8">
        {Object.entries(groupedCustomers).length > 0 ? (
          Object.entries(groupedCustomers).map(([groupName, groupCustomers]) => {
            const isCollapsed = expandedGroups[groupName] === true;
            return (
              <div key={groupName} className="space-y-4">
                <button 
                  onClick={() => toggleGroup(groupName)}
                  className="w-full flex items-center justify-between p-4 glass rounded-2xl hover:bg-white/10 transition-colors group"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 group-hover:bg-blue-500/20 transition-all">
                      <Layers size={20} />
                    </div>
                    <div className="text-left">
                      <h3 className="font-bold text-lg text-white">{groupName}</h3>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{groupCustomers.length} Customers</p>
                    </div>
                  </div>
                  <div className="p-2 rounded-lg bg-white/5">
                    {isCollapsed ? <ChevronRight size={20} className="text-slate-400" /> : <ChevronDown size={20} className="text-blue-400" />}
                  </div>
                </button>

                {!isCollapsed && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-in fade-in slide-in-from-top-2 duration-300">
                    {groupCustomers.map(customer => {
                      const { percentage, remaining } = getCustomerProgress(customer.id, customer.principal, customer.interestRate);
                      return (
                        <div 
                          key={customer.id}
                          onClick={() => onSelect(customer.id)}
                          className="glass p-5 rounded-3xl cursor-pointer hover:bg-white/10 transition-all border border-white/5 group"
                        >
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center space-x-3 overflow-hidden">
                              <div className="w-12 h-12 rounded-2xl overflow-hidden bg-blue-500/20 border border-blue-500/30 flex-shrink-0">
                                {customer.photo ? (
                                  <img src={customer.photo} alt={customer.name} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center">
                                    <User className="text-blue-400" />
                                  </div>
                                )}
                              </div>
                              <div className="min-w-0">
                                <h3 className="font-bold text-white group-hover:text-blue-300 transition-colors truncate">
                                  {customer.name}
                                </h3>
                                <p className="text-[10px] text-slate-500 mt-0.5">ID: {customer.uniqueId}</p>
                              </div>
                            </div>
                            <div className={`flex-shrink-0 px-2 py-1 rounded-lg text-[10px] font-bold uppercase ${remaining <= 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'}`}>
                              {remaining <= 0 ? 'Closed' : 'Active'}
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div className="flex justify-between text-xs">
                              <div className="flex items-center text-slate-400">
                                <Phone size={12} className="mr-1" />
                                {customer.phoneNumber}
                              </div>
                              <div className="flex items-center text-slate-200 font-bold">
                                <span className="mr-1 text-slate-400 font-normal">Bal:</span>
                                <span>₹{remaining.toLocaleString()}</span>
                              </div>
                            </div>

                            <div className="space-y-1">
                              <div className="flex justify-between text-[10px] text-slate-500">
                                <span>Payment Progress</span>
                                <span>{percentage}%</span>
                              </div>
                              <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-blue-500 rounded-full transition-all duration-500" 
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-20 flex flex-col items-center justify-center text-slate-500 glass rounded-3xl">
            <User size={48} className="mb-4 opacity-20" />
            <p>No customers found matching your search</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerList;
