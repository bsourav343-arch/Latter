
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, Cell, PieChart, Pie
} from 'recharts';
import { TrendingUp, Users, DollarSign, ArrowUpRight, ArrowDownRight, Layers } from 'lucide-react';
import { Customer, Installment, Expense } from '../types';

interface DashboardProps {
  customers: Customer[];
  expenses: Expense[];
  installments: Installment[];
  onNavigateToCustomers: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ customers, expenses, installments, onNavigateToCustomers }) => {
  const stats = useMemo(() => {
    const totalPrincipal = customers.reduce((acc, curr) => acc + curr.principal, 0);
    const totalToReceive = customers.reduce((acc, curr) => {
      const total = curr.principal * (1 + curr.interestRate / 100);
      return acc + total;
    }, 0);
    const totalCollected = installments.reduce((acc, curr) => acc + curr.amount, 0);
    const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    const netProfit = totalCollected - totalExpenses;
    
    // Calculate unique groups
    const uniqueGroups = new Set(
      customers
        .map(c => c.groupName)
        .filter(g => g && g.trim() !== '')
    ).size;

    return {
      totalPrincipal,
      totalToReceive,
      totalCollected,
      totalExpenses,
      netProfit,
      pendingCollection: totalToReceive - totalCollected,
      totalGroups: uniqueGroups
    };
  }, [customers, installments, expenses]);

  const collectionData = useMemo(() => {
    // Last 7 days collection
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    return days.map(day => ({
      date: day.split('-').slice(1).join('/'),
      amount: installments
        .filter(inst => inst.date.startsWith(day))
        .reduce((sum, curr) => sum + curr.amount, 0)
    }));
  }, [installments]);

  return (
    <div className="space-y-6">
      {/* Top Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatCard 
          title="Total Capital" 
          value={`₹${stats.totalPrincipal.toLocaleString()}`} 
          icon={<DollarSign className="text-blue-400" />} 
          color="blue"
        />
        <StatCard 
          title="Total Collection" 
          value={`₹${stats.totalCollected.toLocaleString()}`} 
          icon={<TrendingUp className="text-emerald-400" />} 
          color="emerald"
        />
        <StatCard 
          title="Total Expenses" 
          value={`₹${stats.totalExpenses.toLocaleString()}`} 
          icon={<ArrowDownRight className="text-rose-400" />} 
          color="rose"
        />
        <StatCard 
          title="Total Groups" 
          value={stats.totalGroups.toString()} 
          icon={<Layers className="text-orange-400" />} 
          color="orange"
        />
        <StatCard 
          title="Active Customers" 
          value={customers.length.toString()} 
          icon={<Users className="text-purple-400" />} 
          color="purple"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass p-6 rounded-3xl">
          <h3 className="text-lg font-bold mb-6 flex items-center justify-between">
            Weekly Collection Trend
            <span className="text-xs font-normal text-slate-400">Past 7 days</span>
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={collectionData}>
                <defs>
                  <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff20', borderRadius: '12px' }}
                  itemStyle={{ color: '#60a5fa' }}
                  formatter={(value) => [`₹${value.toLocaleString()}`, 'Collected']}
                />
                <Area type="monotone" dataKey="amount" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorAmt)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-6 rounded-3xl flex flex-col justify-center">
          <h3 className="text-lg font-bold mb-4">Financial Health</h3>
          <div className="space-y-4">
            <HealthBar label="Target Returns" value={stats.totalToReceive} max={stats.totalToReceive} color="blue" />
            <HealthBar label="Currently Collected" value={stats.totalCollected} max={stats.totalToReceive} color="emerald" />
            <HealthBar label="Operating Expenses" value={stats.totalExpenses} max={stats.totalCollected} color="rose" />
          </div>
          <div className="mt-8 p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-400">Estimated Net Profit</p>
              <p className="text-xl font-bold text-emerald-400">₹{stats.netProfit.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-emerald-500/20 rounded-xl">
              <TrendingUp className="text-emerald-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity Mini List */}
      <div className="glass p-6 rounded-3xl">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold">Quick Overview</h3>
          <button onClick={onNavigateToCustomers} className="text-sm text-blue-400 hover:underline">View All</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
            <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Missed Today</p>
            <p className="text-2xl font-bold text-white">0</p>
          </div>
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
            <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Payments Pending</p>
            <p className="text-2xl font-bold text-blue-400">₹{stats.pendingCollection.toLocaleString()}</p>
          </div>
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
            <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Members</p>
            <p className="text-2xl font-bold text-purple-400">{customers.length}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
  <div className="glass p-5 rounded-3xl flex flex-col justify-between hover:bg-white/10 transition-colors">
    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center bg-${color}-500/10 mb-4`}>
      {icon}
    </div>
    <div>
      <p className="text-xs text-slate-400 font-medium mb-1">{title}</p>
      <p className="text-xl font-bold text-white">{value}</p>
    </div>
  </div>
);

const HealthBar: React.FC<{ label: string; value: number; max: number; color: 'blue' | 'emerald' | 'rose' }> = ({ label, value, max, color }) => {
  const percentage = Math.min(Math.round((value / (max || 1)) * 100), 100);
  const colorMap = {
    blue: 'bg-blue-500',
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500'
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs">
        <span className="text-slate-400">{label}</span>
        <span className="font-bold">₹{value.toLocaleString()} ({percentage}%)</span>
      </div>
      <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
        <div className={`h-full ${colorMap[color]} rounded-full transition-all duration-1000`} style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
}

export default Dashboard;
