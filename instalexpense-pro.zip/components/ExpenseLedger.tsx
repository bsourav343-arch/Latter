
import React, { useState, useMemo } from 'react';
import { 
  Plus, Wallet, Receipt, Trash2, Edit2, X, Search, 
  Filter, Calendar, ArrowUpRight, ArrowDownRight, Tag 
} from 'lucide-react';
import { Expense } from '../types';

interface ExpenseLedgerProps {
  expenses: Expense[];
  onSave: (e: Expense) => void;
}

const ExpenseLedger: React.FC<ExpenseLedgerProps> = ({ expenses, onSave }) => {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Operating');
  const [reason, setReason] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');

  const categories = ['Operating', 'Salary', 'Utility', 'Rent', 'Others'];

  const stats = useMemo(() => {
    const total = expenses.reduce((sum, curr) => sum + curr.amount, 0);
    const thisMonth = expenses
      .filter(ex => new Date(ex.date).getMonth() === new Date().getMonth())
      .reduce((sum, curr) => sum + curr.amount, 0);
    const topCategory = categories.reduce((prev, curr) => {
      const currentSum = expenses.filter(e => e.category === curr).reduce((s, c) => s + c.amount, 0);
      const prevSum = expenses.filter(e => e.category === prev).reduce((s, c) => s + c.amount, 0);
      return currentSum > prevSum ? curr : prev;
    }, 'Operating');

    return { total, thisMonth, topCategory };
  }, [expenses]);

  const filteredExpenses = useMemo(() => {
    return expenses
      .filter(ex => {
        const matchesSearch = ex.reason.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = filterCategory === 'All' || ex.category === filterCategory;
        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, searchTerm, filterCategory]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !reason) return;
    onSave({
      id: editingId || crypto.randomUUID(),
      amount: parseFloat(amount),
      category,
      reason,
      date: editingId ? expenses.find(ex => ex.id === editingId)?.date || new Date().toISOString() : new Date().toISOString()
    });
    resetForm();
  };

  const resetForm = () => {
    setAmount('');
    setReason('');
    setCategory('Operating');
    setEditingId(null);
  };

  const handleEdit = (exp: Expense) => {
    setAmount(exp.amount.toString());
    setCategory(exp.category);
    setReason(exp.reason);
    setEditingId(exp.id);
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass p-6 rounded-[32px] border-l-4 border-blue-500">
          <p className="text-xs text-slate-500 font-bold uppercase mb-1">Total Lifetime Cost</p>
          <div className="flex justify-between items-end">
            <h4 className="text-2xl font-bold">₹{stats.total.toLocaleString()}</h4>
            <Wallet size={20} className="text-blue-500/50 mb-1" />
          </div>
        </div>
        <div className="glass p-6 rounded-[32px] border-l-4 border-emerald-500">
          <p className="text-xs text-slate-500 font-bold uppercase mb-1">Expenses This Month</p>
          <div className="flex justify-between items-end">
            <h4 className="text-2xl font-bold">₹{stats.thisMonth.toLocaleString()}</h4>
            <Calendar size={20} className="text-emerald-500/50 mb-1" />
          </div>
        </div>
        <div className="glass p-6 rounded-[32px] border-l-4 border-purple-500">
          <p className="text-xs text-slate-500 font-bold uppercase mb-1">Highest Burn Category</p>
          <div className="flex justify-between items-end">
            <h4 className="text-2xl font-bold">{stats.topCategory}</h4>
            <Tag size={20} className="text-purple-500/50 mb-1" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Entry Form */}
        <div className="lg:col-span-1">
          <div className="glass p-8 rounded-[40px] sticky top-24 border border-white/5 electric-blue-glow">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xl font-bold flex items-center">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${editingId ? 'bg-blue-600' : 'bg-emerald-600'}`}>
                  {editingId ? <Edit2 size={16} /> : <Plus size={16} />}
                </div>
                {editingId ? 'Modify Record' : 'Log New Outflow'}
              </h3>
              {editingId && (
                <button onClick={resetForm} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-500">
                  <X size={20} />
                </button>
              )}
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-[10px] text-slate-500 font-bold mb-2 block uppercase tracking-widest">Amount (₹)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">₹</span>
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-10 pr-4 focus:ring-2 focus:ring-blue-500 focus:outline-none text-white text-lg font-bold transition-all"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 font-bold mb-2 block uppercase tracking-widest">Classification</label>
                <div className="grid grid-cols-2 gap-2">
                  {categories.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCategory(c)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${category === c ? 'bg-blue-600 border-blue-500 text-white' : 'bg-white/5 border-white/10 text-slate-500 hover:border-white/20'}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 font-bold mb-2 block uppercase tracking-widest">Purpose / Description</label>
                <textarea 
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 focus:ring-2 focus:ring-blue-500 focus:outline-none text-white text-sm min-h-[100px] resize-none"
                  placeholder="What was this for?"
                />
              </div>

              <button 
                type="submit"
                className={`w-full py-5 rounded-[32px] font-bold text-lg flex items-center justify-center space-x-2 transition-all transform active:scale-[0.98] ${editingId ? 'bg-blue-600 electric-blue-glow' : 'bg-emerald-600 shadow-emerald-500/20 shadow-lg'}`}
              >
                {editingId ? <ArrowUpRight size={20} /> : <Plus size={20} />}
                <span>{editingId ? 'Commit Changes' : 'Execute Payment'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* Expense History List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h3 className="text-xl font-bold flex items-center">
              <Receipt className="mr-2 text-slate-400" />
              General Expense Ledger
            </h3>
            
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 custom-scrollbar no-print">
              {['All', ...categories].map(c => (
                <button
                  key={c}
                  onClick={() => setFilterCategory(c)}
                  className={`flex-shrink-0 px-4 py-2 rounded-full text-[10px] font-bold uppercase transition-all ${filterCategory === c ? 'bg-slate-200 text-slate-900' : 'bg-white/5 text-slate-500 hover:bg-white/10'}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
              type="text" 
              placeholder="Filter expenses by description..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-3xl glass border-white/10 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm"
            />
          </div>

          <div className="space-y-4">
            {filteredExpenses.length > 0 ? filteredExpenses.map(exp => (
              <div key={exp.id} className="glass p-6 rounded-[32px] flex items-center justify-between border border-white/5 group hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center space-x-5">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${exp.category === 'Salary' ? 'bg-purple-500/10 text-purple-400' : 'bg-white/5 text-slate-500'}`}>
                    <Tag size={24} />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="px-2 py-0.5 bg-white/5 rounded text-[8px] font-bold text-slate-500 uppercase tracking-tighter">{exp.category}</span>
                      <span className="text-[10px] text-slate-500">{new Date(exp.date).toLocaleDateString()}</span>
                    </div>
                    <p className="font-bold text-white text-lg group-hover:text-blue-300 transition-colors">{exp.reason}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-6">
                  <div className="text-right">
                    <p className="text-xl font-bold text-rose-400">-₹{exp.amount.toLocaleString()}</p>
                  </div>
                  <div className="flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button 
                      onClick={() => handleEdit(exp)}
                      className="p-2 glass rounded-xl hover:bg-blue-500/20 text-blue-400 transition-colors"
                    >
                      <Edit2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            
            {filteredExpenses.length === 0 && (
              <div className="py-24 text-center text-slate-500 glass rounded-[40px] flex flex-col items-center">
                <Receipt size={48} className="mb-4 opacity-10" />
                <p className="text-lg font-medium">No ledger entries matching criteria</p>
                <p className="text-xs opacity-50">Try adjusting your filters or search terms</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpenseLedger;
