import React, { useMemo } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { TrendingUp, DollarSign, Wallet, BarChart3, PieChart as PieChartIcon } from 'lucide-react';
import { Customer, Installment, Expense } from '../types';

interface RevenueViewProps {
  customers: Customer[];
  installments: Installment[];
  expenses: Expense[];
}

const RevenueView: React.FC<RevenueViewProps> = ({ customers, installments, expenses }) => {
  const revenueStats = useMemo(() => {
    const totalPrincipal = customers.reduce((acc, curr) => acc + curr.principal, 0);
    const totalExpectedInterest = customers.reduce((acc, curr) => {
      return acc + (curr.principal * curr.interestRate / 100);
    }, 0);
    const totalFines = customers.reduce((acc, curr) => acc + curr.fineAmount, 0);
    const totalExpectedRevenue = totalExpectedInterest + totalFines;
    const totalExpectedReturns = totalPrincipal + totalExpectedRevenue;
    const totalCollected = installments.reduce((acc, curr) => acc + curr.amount, 0);
    const revenueShareFactor = totalExpectedReturns > 0 ? totalExpectedRevenue / totalExpectedReturns : 0;
    const actualRevenueCollected = totalCollected * revenueShareFactor;
    const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    const netRevenue = actualRevenueCollected - totalExpenses;
    const yieldEfficiency = totalExpectedRevenue > 0 ? (actualRevenueCollected / totalExpectedRevenue) * 100 : 0;
    const roiIndex = totalPrincipal > 0 ? totalExpectedReturns / totalPrincipal : 0;

    return {
      totalExpectedInterest,
      totalFines,
      actualRevenueCollected,
      totalExpenses,
      netRevenue,
      yieldEfficiency,
      roiIndex,
      totalExpectedRevenue
    };
  }, [customers, installments, expenses]);

  const groupBreakdown = useMemo(() => {
    const groups: Record<string, number> = {};
    customers.forEach(c => {
      const gName = c.groupName || 'General';
      const interest = (c.principal * c.interestRate / 100) + c.fineAmount;
      groups[gName] = (groups[gName] || 0) + interest;
    });

    return Object.entries(groups).map(([name, value]) => ({ name, value }));
  }, [customers]);

  const monthlyTrend = useMemo(() => {
    const last6Months = Array.from({ length: 6 }, (_, i) => {
      const d = new Date();
      d.setMonth(d.getMonth() - (5 - i));
      return {
        month: d.getMonth(),
        year: d.getFullYear(),
        label: d.toLocaleString('default', { month: 'short' }),
        revenue: 0,
        expenses: 0
      };
    });

    const totalPrincipal = customers.reduce((acc, curr) => acc + curr.principal, 0);
    const totalInt = customers.reduce((acc, curr) => acc + (curr.principal * curr.interestRate / 100), 0);
    const totalFines = customers.reduce((acc, curr) => acc + curr.fineAmount, 0);
    const factor = (totalPrincipal + totalInt + totalFines) > 0 ? (totalInt + totalFines) / (totalPrincipal + totalInt + totalFines) : 0;

    last6Months.forEach(m => {
      const monthInst = installments.filter(inst => {
        const d = new Date(inst.date);
        return d.getMonth() === m.month && d.getFullYear() === m.year;
      });
      m.revenue = monthInst.reduce((s, c) => s + c.amount, 0) * factor;

      const monthExp = expenses.filter(exp => {
        const d = new Date(exp.date);
        return d.getMonth() === m.month && d.getFullYear() === m.year;
      });
      m.expenses = monthExp.reduce((s, c) => s + c.amount, 0);
    });

    return last6Months;
  }, [installments, expenses, customers]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center">
          <TrendingUp className="mr-3 text-blue-400" />
          Revenue Analytics
        </h2>
        <div className="text-xs text-slate-500 bg-white/5 px-3 py-1 rounded-full border border-white/5 uppercase tracking-tighter font-bold">
          Automatic Tracking
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Int. (Expected)" 
          value={`₹${revenueStats.totalExpectedInterest.toLocaleString()}`} 
          subtitle="Lifetime projected interest"
          icon={<DollarSign size={20} />} 
          color="blue"
        />
        <StatCard 
          title="Fines (Expected)" 
          value={`₹${revenueStats.totalFines.toLocaleString()}`} 
          subtitle="Total accumulated fines"
          icon={<TrendingUp size={20} />} 
          color="amber"
        />
        <StatCard 
          title="Operating Costs" 
          value={`₹${revenueStats.totalExpenses.toLocaleString()}`} 
          subtitle="Cumulative expenses"
          icon={<Wallet size={20} />} 
          color="rose"
        />
        <StatCard 
          title="Net Revenue" 
          value={`₹${revenueStats.netRevenue.toLocaleString()}`} 
          subtitle="Collected Revenue - Expenses"
          icon={<BarChart3 size={20} />} 
          color="emerald"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass p-6 rounded-[32px]">
          <h3 className="text-lg font-bold mb-6">Growth Performance (Last 6 Months)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyTrend}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis dataKey="label" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} tickFormatter={(val) => `₹${val >= 1000 ? (val/1000).toFixed(0) + 'k' : val}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff10', borderRadius: '16px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', paddingTop: '20px' }} />
                <Area type="monotone" dataKey="revenue" name="Actual Revenue Collected" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#revenueGrad)" />
                <Area type="monotone" dataKey="expenses" name="Operating Expenses" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#expenseGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-6 rounded-[32px] flex flex-col">
          <h3 className="text-lg font-bold mb-6 flex items-center">
            <PieChartIcon className="mr-2 text-purple-400" size={18} />
            Profit Distribution
          </h3>
          <div className="h-[250px] w-full flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={groupBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {groupBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff10', borderRadius: '12px' }}
                   formatter={(val) => `₹${val.toLocaleString()}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2 max-h-32 overflow-y-auto pr-2 custom-scrollbar">
            {groupBreakdown.length > 0 ? groupBreakdown.map((g, i) => (
              <div key={g.name} className="flex justify-between items-center text-xs">
                <div className="flex items-center">
                  <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-slate-400 truncate max-w-[100px]">{g.name}</span>
                </div>
                <span className="font-bold">₹{g.value.toLocaleString()}</span>
              </div>
            )) : (
              <p className="text-[10px] text-slate-500 text-center italic">No data available</p>
            )}
          </div>
        </div>
      </div>

      <div className="glass p-8 rounded-[40px] border border-white/5 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-10 transition-opacity group-hover:opacity-20 pointer-events-none">
          <TrendingUp size={120} />
        </div>
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-xl font-bold mb-2">Automated Optimization Insights</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Your business is operating at a <span className="text-emerald-400 font-bold">{(revenueStats.actualRevenueCollected > 0 ? (revenueStats.netRevenue / revenueStats.actualRevenueCollected * 100) : 0).toFixed(1)}%</span> net margin. 
              The system analyzes historical data to generate real-time Yield and ROI indexes.
            </p>
            <div className="flex space-x-4">
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-2xl p-4 flex-1">
                <p className="text-[10px] text-blue-400 font-bold uppercase mb-1">Yield Efficiency</p>
                <p className="text-2xl font-bold">{revenueStats.yieldEfficiency.toFixed(1)}%</p>
              </div>
              <div className="bg-emerald-600/10 border border-emerald-500/20 rounded-2xl p-4 flex-1">
                <p className="text-[10px] text-emerald-400 font-bold uppercase mb-1">ROI Index</p>
                <p className="text-2xl font-bold">{revenueStats.roiIndex.toFixed(2)}</p>
              </div>
            </div>
          </div>
          <div className="bg-white/5 rounded-3xl p-6 border border-white/5">
            <h4 className="text-sm font-bold mb-4">Top Expected Revenue Sources</h4>
            <div className="space-y-4">
              {groupBreakdown.sort((a,b) => b.value - a.value).slice(0, 3).map((g, i) => (
                <div key={g.name} className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="truncate max-w-[120px]">{g.name}</span>
                    <span className="text-blue-400 font-bold">₹{g.value.toLocaleString()}</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-500 rounded-full transition-all duration-1000" 
                      style={{ width: `${revenueStats.totalExpectedRevenue > 0 ? Math.min((g.value / revenueStats.totalExpectedRevenue) * 100, 100) : 0}%` }} 
                    />
                  </div>
                </div>
              ))}
              {groupBreakdown.length === 0 && <p className="text-xs text-slate-500 italic py-4">Assign customers to groups to see breakdown.</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ 
  title: string; 
  value: string; 
  subtitle: string; 
  icon: React.ReactNode; 
  color: 'blue' | 'emerald' | 'rose' | 'amber' 
}> = ({ title, value, subtitle, icon, color }) => {
  const colorMap = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    rose: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  };

  return (
    <div className={`glass p-6 rounded-[32px] border transition-all hover:scale-[1.02] duration-300`}>
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${colorMap[color]}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">{title}</p>
        <p className="text-2xl font-bold text-white mb-1">{value}</p>
        <p className="text-[10px] text-slate-500">{subtitle}</p>
      </div>
    </div>
  );
};

export default RevenueView;