
import React, { useState } from 'react';
import { Save, User, Shield, Info, Database, Camera } from 'lucide-react';
import { Settings } from '../types';

interface SettingsViewProps {
  settings: Settings;
  onSave: (s: Settings) => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ settings, onSave }) => {
  const [adminName, setAdminName] = useState(settings.adminName);
  const [adminPhoto, setAdminPhoto] = useState(settings.adminPhoto);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAdminPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center space-x-4 mb-8">
        <div className="p-4 bg-blue-600/20 rounded-3xl text-blue-400">
          <Shield size={32} />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Admin Configuration</h2>
          <p className="text-slate-500 text-sm">Manage your application preferences</p>
        </div>
      </div>

      <div className="glass p-8 rounded-[40px] space-y-8 max-w-2xl">
        <section className="space-y-6">
          <h3 className="text-sm font-bold text-blue-400 uppercase tracking-widest flex items-center">
            <User className="mr-2" size={16} />
            Profile Identity
          </h3>
          
          <div className="flex flex-col items-center sm:flex-row sm:items-start gap-8">
             <div className="relative group">
                <div className="w-32 h-32 rounded-[32px] overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center transition-all group-hover:border-blue-500/50">
                  {adminPhoto ? (
                    <img src={adminPhoto} alt="Admin Profile" className="w-full h-full object-cover" />
                  ) : (
                    <User size={48} className="text-white/20" />
                  )}
                </div>
                <label className="absolute -bottom-2 -right-2 p-2 bg-blue-600 rounded-xl cursor-pointer hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/30">
                  <Camera size={16} />
                  <input type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
                </label>
             </div>

             <div className="flex-1 space-y-2 w-full">
                <label className="text-xs text-slate-500 font-bold ml-1 uppercase tracking-wider">Administrator Name</label>
                <input 
                  type="text"
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold text-lg"
                  placeholder="e.g. Rahul Sharma"
                />
             </div>
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-widest flex items-center">
            <Database className="mr-2" size={16} />
            Data Persistence
          </h3>
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-300">Local Storage Sync</span>
              <span className="text-xs px-2 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold">ACTIVE</span>
            </div>
            <p className="text-xs text-slate-500">Your data is stored locally using IndexedDB. It persists across sessions and works offline.</p>
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center">
            <Info className="mr-2" size={16} />
            App Information
          </h3>
          <div className="space-y-1 text-xs text-slate-500">
            <p>Version: 1.0.5-Premium</p>
            <p>Localization: INR (India)</p>
            <p>Built for: Enterprise Installment Management</p>
          </div>
        </section>

        <button 
          onClick={() => onSave({ adminName, adminPhoto })}
          className="w-full py-5 bg-blue-600 rounded-[32px] font-bold text-lg flex items-center justify-center space-x-2 electric-blue-glow hover:bg-blue-500 transition-all shadow-lg"
        >
          <Save size={20} />
          <span>Apply Changes</span>
        </button>
      </div>
    </div>
  );
};

export default SettingsView;
