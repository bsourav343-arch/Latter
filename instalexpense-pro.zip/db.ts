import { openDB, IDBPDatabase } from 'idb';
import { Customer, Installment, Expense, Settings } from './types';

const DB_NAME = 'InstalExpenseDB';
const DB_VERSION = 1;

class DatabaseService {
  private dbPromise: Promise<IDBPDatabase>;

  constructor() {
    this.dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('customers')) {
          db.createObjectStore('customers', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('installments')) {
          const store = db.createObjectStore('installments', { keyPath: 'id' });
          store.createIndex('customerId', 'customerId');
        }
        if (!db.objectStoreNames.contains('expenses')) {
          db.createObjectStore('expenses', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      }
    });
  }

  async getCustomers(): Promise<Customer[]> {
    const db = await this.dbPromise;
    return db.getAll('customers');
  }

  async saveCustomer(customer: Customer) {
    const db = await this.dbPromise;
    await db.put('customers', customer);
  }

  async deleteCustomer(id: string) {
    const db = await this.dbPromise;
    await db.delete('customers', id);
  }

  async getInstallments(customerId?: string): Promise<Installment[]> {
    const db = await this.dbPromise;
    if (customerId) {
      return db.getAllFromIndex('installments', 'customerId', customerId);
    }
    return db.getAll('installments');
  }

  async saveInstallment(installment: Installment) {
    const db = await this.dbPromise;
    await db.put('installments', installment);
  }

  async getExpenses(): Promise<Expense[]> {
    const db = await this.dbPromise;
    return db.getAll('expenses');
  }

  async saveExpense(expense: Expense) {
    const db = await this.dbPromise;
    await db.put('expenses', expense);
  }

  async getSettings(): Promise<Settings> {
    const db = await this.dbPromise;
    const s = await db.get('settings', 'main');
    return s ? s.value : { adminName: 'Admin' };
  }

  async saveSettings(settings: Settings) {
    const db = await this.dbPromise;
    await db.put('settings', { key: 'main', value: settings });
  }
}

export const dbService = new DatabaseService();