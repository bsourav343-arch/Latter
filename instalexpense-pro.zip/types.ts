
export interface Customer {
  id: string;
  name: string;
  groupName: string;
  uniqueId: string; // Internal Account/Unique ID
  idCardNumber: string; // Aadhaar or Voter ID Number
  guardianName: string;
  phoneNumber: string;
  photo?: string; // base64
  aadhaarCard?: string; // base64
  voterId?: string; // base64
  principal: number;
  interestRate: number; // Flat percentage
  totalWeeks: number;
  startDate: string;
  fineAmount: number;
  // Address Fields
  pinCode: string;
  village: string;
  state: string;
  district: string;
  policeStation: string;
}

export interface Installment {
  id: string;
  customerId: string;
  amount: number;
  date: string;
  type: 'regular' | 'advance';
}

export interface Expense {
  id: string;
  amount: number;
  category: string;
  reason: string;
  date: string;
}

export interface Settings {
  adminName: string;
  adminPhoto?: string; // base64
}

export type Screen = 'dashboard' | 'customers' | 'expenses' | 'settings' | 'customerDetail' | 'revenue';
